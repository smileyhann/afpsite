<?php 
//This plugin creates an entry in the options database. When the plugin will be deleted, this code will automatically delete the database entry from the options WordPress table.
delete_option('wpts_options'); 
delete_option('wpts_db_version'); 
?>