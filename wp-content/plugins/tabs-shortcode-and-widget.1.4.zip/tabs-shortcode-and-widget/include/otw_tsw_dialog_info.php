<?php
$otw_tsw_dialog_text = 'Check out the full version of the <a href="http://otwthemes.com/product/content-manager-for-wordpress/?utm_source=wp.org&amp;utm_medium=admin&amp;utm_content=upgrade&amp;utm_campaign=cml">Content Manager for WordPress</a>.';
?>