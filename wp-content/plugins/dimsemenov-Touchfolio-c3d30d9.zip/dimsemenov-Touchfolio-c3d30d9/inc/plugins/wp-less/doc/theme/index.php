<?php get_header() ?>

<h1>Unleash LESS power!</h1>

<p>Thanks for using the plugin.</p>

<?php get_footer() ?>