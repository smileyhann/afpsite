=== Vertical Tab Slider ===
Contributors: wptreasure 
Donate link: http://wptreasure.com/
Tags: vertical tab slider, content slider, slider, image slider, text slider, tab slider, accordian slider, accordian, image rotator, image cycle, content rotator 
Requires at least: 3.0
Tested up to: 3.9.2
Stable tag: 1.2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A very attractive and cool looking tabbing slider which gives a user to rotate their images and description in slides with great effect.

== Description ==

A very attractive and cool looking tabbing slider which gives a user to rotate their images and their defined description in slides with a great effect which are manageable using admin section.  
  

* Can add a different slider tabs with their title, description and images
* Can set a link on slider image description.
* Can set a border width and border color of slider.
* Can set width and height of slider images.
* Can manage a width of content section of slider that is tabbing section.
* Can manage a navigation of slider that you want to show or not.
* Can manage a Autoplay of slider images that is you wnat to autoplay slider or not.
* Can set different effect on slider that is Slide-Left, Slide-Right, Slide-Up, Slide-Down.
* Can manage "Delay Between Slides".
* Can manage "Transition Speed" for a slides.

  
For how to use & Demo click here : http://wptreasure.com/downloads/vertical-tab-slider/


== Installation ==

Upload the plugin folder to the /wp-content/plugins/ folder of your WordPress installation.  
Activate the plugin.  
You will see an option at the left side WordPress options option panel named "V-Tab Slider".  
Click on it to set the options.  
Enjoy it......


== Frequently Asked Questions ==

= A question that will be asked by users =

== Screenshots ==

1. The admin settings page.
2. Frontend display.

== Changelog ==

=Version 1.2.2=

* Added enable/disable link over image option in admin settings.
* Addded link target option in admin settings.

=Version 1.1.2=

* Removed referrer link.

=Version 1.1.1=

* Compatible with the WordPress latest version (3.9).

=Version 1.1.0=

* Added Responsive Functionality

=Version 1.0.0=

* Initial Release


== Upgrade notice ==

* Initial Release

== Arbitrary section 1 ==
