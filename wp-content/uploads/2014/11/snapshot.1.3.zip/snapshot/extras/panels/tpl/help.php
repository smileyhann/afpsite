<p>
	<?php _e('SiteOrigin themes include a unique page building tool.', 'snapshot') ?>
	<?php _e('You can use this tool to create home and sub pages, filled your own widgets.', 'snapshot') ?>
	<?php _e('The page layouts are responsive and completely customizable.', 'snapshot') ?>
</p>
<p>
	<?php printf( __( "Read the <a href='%s' target='_blank'>full documentation</a> on SiteOrigin's support site.", 'snapshot' ), 'http://siteorigin.com/page-builder/documentation/' ) ?>
</p>